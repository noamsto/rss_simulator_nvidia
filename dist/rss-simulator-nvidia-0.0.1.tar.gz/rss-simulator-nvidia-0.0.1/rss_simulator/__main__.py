"""RSS simulator package __main__ module."""
from rss_simulator import main

main()
