"""Argument parser types package __init__ module."""
from rss_simulator.arg_parse_types.arg_parse_type_decorator import arg_parse_type_decorator
from rss_simulator.arg_parse_types.positive_int import PositiveInt
