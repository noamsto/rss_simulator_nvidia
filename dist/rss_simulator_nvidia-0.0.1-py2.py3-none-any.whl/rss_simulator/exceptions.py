"""Exceptions classes raised by various operations."""
class ParseException(Exception):
    """Raised when parsing exception occurred."""
