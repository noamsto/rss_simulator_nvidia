"""RSS simulator package __init__ module."""
from rss_simulator.main import main
